![[Screenshot 2024-09-12 at 11.52.56.png]]**IEEE Standards**
The Institute of Electrical and Electronics engineers (IEEE) Project 802 was started to establish LAN standards:

- **802.3** – LAN architecture to run CSMA/CD (Ethernet)  
- **802.5** – LAN architecture to run on Token Ring network.  
- **802.6** – LAN architecture for MANs. (Metropolitan Networks)  
 - **802.8** – LAN architecture deals with fiber-optic implementation of Ethernet (Fiber Optic Tag)
 - **802.9** – LAN deals with integrated data and voice (Isochronous LANs)  
 - **802.11x** – Wireless LAN
	 - **802.11b**: Max 11 Mbit/s  
	 - **802.11g**: Max 54 Mbit/s  
	 - **802.11i**: (aka WPA2) specifies security mechanisms for wireless LANs.

**802.1x & 802.11x är INTE samma sak.**
- 802.1x är authentication standard
- 802.11x är Wi-Fi standard 

**WAP**: Wireless access point

**IEEE 802.11**: 2 standarder för authenticating
1. OSA: ingen confidentiality eller integrity för den är okrypterad
2. SKA: någon form av autentisering. Om autentisering inte är tillhandahållen blockerar den kommunikation. Tekniker kan vara WEP, WPA, WPA2, WPA3. WPA3 är nuvarande standard

**WEP**: använder RC4 (Rivest Cypher 4, symmetrisk) anv. Static Encryption Key. To narrow of an initialization vector. 

**WPA** successor to WEP
- **LEAP** lightweight extensible access protocol
- **TKIP** Temporal Key Integrity Protocol  
- Negotiates a unique key set with each host 
- Cracked in 2008 using a known cypher-text approach
  
**WPA2** 
Använder: **AES**, **802.1x** based authentication, CCMP (**CCM** with **CRT** mode) 

1. **WPA2 Personal**
	- Setup password
2. **WPA2 Enterprise**
	- Using NAC (Network Access Control) like RADIUS
	- Broken with Krack 

**WPA3** 
- Uses Dragonfly algorithm 
- Broken using Dragonblood

**802.1X Enterprise authentication:** 
- Can use radius, Tacans, certificates, smart cards, token devices, and biometric can be integrated



**EAP: extensible Authentication Protocol** 
- **EAP** is an authentication framework
- **LEAP**: Lightweight Extensible Authentication Protocol - Cisco propitiatory alternative to TKIP for WPA
- **PEAP**: Protected Extensible Authentication Protocol. Encapsulates EAP methods to provide authentication and potentially encryption 
- **EAP-TLS**
- **SEAP-SIM**
- **EAP-AKA**
- **EAP-TTLS**
- **CCMP**: Counter mode with Cipher Block Chaining Message Authentication Code Protocol. 
  Uses AES with 128-bit key preffered standard for 802.11 and is standard mechanism for WPA2
  
**Data processing** tends to refer to applying logic and reasoning to make sure that all of the observations conform to an acceptable quality and consistency standard. This is sometimes called data cleaning (to remove errors and biases), data validation (to compare it to a known, accepted, and authoritative source), or data smoothing (to remove data samples that are so “out of range” that they indicate a mistaken observation and should not be used in further processing).

**Information processing** usually is the first step in a series of actions where we apply business logic to the data to inform or enable the next step in a business process. Generating employee payroll from the time cards might require validating that the employee is correctly identified and that the dates and hours agree with the defined pay period, and then applying the right pay formula to those hours to calculate gross pay earned for that period.

**SAML** Security Assertion Markup Language. For exchanging authentication and authorization data (mainly SSO). 3 entities in a SAML relationship
	1. **Subject** (Principal) - the end user
	2. **Identity provider** is the organization providing the users account that is used for authentication.
	3. **Service provider** is the organization offering the service requested by the end user.

**SPML**: For provisioning and managing user accounts and services. Designed to allow platforms to generate and respond to provisioning requests. 
**XACML**: For defining and enforcing access control policies
**SOAP**: For secure, reliable communication between web services
**SCIM**: System for Cross-domain Identity Management: used by cloud based systems and applications to streamline to automate identity provisioning

**Network Access Control (NAC)** focuses on the logical controls necessary to carry out management decisions, as specified in administrative controls such as corporate policies, procedures or guidelines.
 ![[Screenshot 2024-09-05 at 08.34.08.png]]

Windows offers **Active Directory** as a centralized identity store. This facilitates logging into Windows systems and other services that support Active Directory authentication. Microsoft also offers Active 

**Directory Federation Services (ADFS)** to facilitate integration with other service providers, enabling a true single sign-on experience.

**Privileged Access Management** (PAM) is a security strategy that controls and monitors access to critical systems and sensitive information by privileged users, ensuring that only authorized individuals have the necessary permissions to perform administrative tasks.

![[Screenshot 2024-09-05 at 08.35.24.png]]

![[Get more data and.png]]

**SIEM** (Security information and event management): 
Systems provide a centralized point aggregation, correlation, and analysis. They must be **tuned** to reduce the number of false positive and false negative alerts. This is called **noise reduction**.

**SLE** Single loss expectancy = Asset Value \* Exposure Factor
**EF** Exposure Factor = Loss / Total Asset Value
**ALE** Annual Loss Expectancy = ARO \* 
**Cost of Control** = cost for risk mitigation

**MAO**: Maximum Acceptable Outage AKA
		MTO: Maximum Tolerable Outage
		MTD: Maximum Tolerable Downtime 
		MTPOD 
**RTO**: Recovery time Objective <= MAO
**RPO**: Recovery point objective. Max data the org is willing to loose


**Risk reviews** should consider all internal and external/ supplier risks and their impact on the  organization and its architecture

**NIST**
- **SP 800-53A**: Methods for Assessing & Measuring control
- **800-12**: Intro to computer security
- **800-34**: Contingency Planning Guide for Federal Information Systems 
- **800-86**: Integrated Forensic techniques into incident response

**NIST SP 800-37 Risk Management Framework**
![[Screenshot 2024-09-05 at 12.56.13.png]]

**Risk registers** are centralized documents used to track information about the risks facing an organization and their current status. They contain a description of each risk, the risks’ priority and category, a risk assessment (including likelihood, impact, and exposure rating), the risk response type/cost/description, the risk owner, and the current status.

**Threat intelligence** shares risk information across organizations and may be used strategically and/ or operationally. Threat intelligence often includes **indicators of compromise (IOC)** that are telltale signs of malicious activity. 

**Threat modeling** identifies and prioritizes threats through a structured approach.
focuses attention on boundaries between systems elements and the outside world, and this may help you discover poorly secured VPN or maintenance features or tunnels installed by malware 

There are 3 major approaches to threat identification:

 1. **Asset focused** approaches use the asset inventory as the basis for the analysis
 2. **Threat focused** approaches identify how specific threats may affect each information system
 3. **Service focused** approaches identify the impact of various threats on a specific service

**ATT&CK**: MITRE’s Adversarial Tactics, Techniques, and Common Knowledge framework is a collection of information about the techniques used by attackers seeking to gain access to an organization and its systems.

**Security audits** use testing and assessment techniques but are performed by independent auditors. There are three types of security audits:
- **Internal audits** are performed by an organization’s internal audit staff, normally led by a Chief Audit Executive who reports directly to the CEO.
- **External audits** are performed by an outside auditing firm.
- **Third-party audits** are conducted by, or on behalf of, another organization, such as a regulator

These engagements produce two different types of reports:
- **Type I reports** provide a description of the controls in place, as described by the audited organization, and the auditor’s opinion whether the controls described are sufficient. The auditor does not test the controls.
-  **Type II reports** document engagements where the auditor actually tests the controls and provides an opinion on their effectiveness.

**COBIT**, **ISO** **27001**, and **ISO** **27002** commonly used standards for cybersecurity audits.


**LDAP**: Lightweight Directory Access Protocol.

**IDP**: Identity Provider
Identitetsleverantör är en systemenhet som skapar, underhåller och hanterar identitetsinformation för huvudmän och som också tillhandahåller autentiseringstjänster till förlitande applikationer inom en federation eller ett distribuerat nätverk.

**SCIF**: Sensitive Compartmented Information Facility

**Bracketing**: Temp increased privileges within a process (sudo eller liknande) 

**Synchronous token**: Google Auth

**Asynchronous Token**: also called a Challenge/Response token. They do not need event counters or internal clocks to operate. Instead, the authentication process sends a challenge ⁠— short string of letters/numbers ⁠— which the user must enter into the token to generate a response.

**RFID**: Radio Frequency ID ![[Pasted image 20240905132555.png]]

**Provisioning**: the process of creating user accounts & granting access to appropriate resources

**Entitlement**: Refers to privileges granted when an account is first provisioned.

**information security baseline** Information that documents an organization’s information security risks, its chosen mitigation approaches, and its decisions about residual risk

**information security baseline** Information that documents an organization’s information security risks, its chosen mitigation approaches, and its decisions about residual risk

**OpenVAS**:  Open source vulnerability scanner
**NIKTO**: Vuln scanner for web servers and web  - Open source
**Metasploit**: for systems
**MBSA**: 
**Nessus**: Vuln Scanner - propriotairy
**John the Ripper**: Password cracking toll that requires both
1. /etc/passwd file
2. /etc/shadow file

**Microsoft STRIDE threat assessment model**: places threats into one of 6 categories
1. Spoofing
2. Tampering
3. Repudiation
4. Information Disclosure
5. DOS
6. Elevation of privileges

**MPLS**: networking technology that routes traffic using the shortest path based on “labels,” rather than network addresses, to handle forwarding over private wide area networks

**Source Code Escrow**
![[Pasted image 20240905171703.png]]

**Netflow Data**: contains information on the source, destination, and size of all network communications and is routinely saved as a matter of normal activity. 

**Disaster recovery process**:

**Regression testing**: is a type of function or unit testing to ensure that changes have note introduced new issues
**Nonregression tesing**: checks to see whether a change has had the effect it was suppose to
**smoke testing**: focuses on simple problems with impact on critical functions

**eDiscovery**: a form of digital investigation that attempts to find evidence in email, business communications and other data that could be used in litigation or criminal proceedings

**Incident response progress stages**

**Radius**: MD5 stronges algo

**Containment**: Addresses shutting down connectivity between networks, subnets, systems and servers. 

**Eradication**: Addresses locating the casual agents (malware, gogus user ID's, etc) and removing them from each system.

**IPsec**: Works at **layer 3** (Network layer)
A method of setting up a secure channel for protected data exchange between two devices. Provides security to the actual IP packets at the network layer. Is usually used to establish VPN. It is an open, modular framework that provides a lot of flexibility. Suitable only to protect upper layer protocols. IPSec uses two protocols: AH and ESP.

**AH (Authentication Header):** Supports access control, data origin authentication, and connectionless integrity. AH provides integrity, authentication and non-repudiation - does NOT provide confidentiality. 
**ESP (Encapsulating Security Payload):** Uses cryptographic mechanism to provide source authentication (by IP header), confidentiality and message integrity.
- **ESP tranport mode**: encrypts IP packet data but leaves the header unencrypted.
  (for peer-to-peer)
- **ESP tunnel mode**: encrypts the entire packet and adds a new header to support transmission through the tunnel. 
  (for gateway-to-gateway)


**Information risk management**
1. Set priorities
2. assess risks
3. select controls and countermeasures
4. implement controls
5. validate correct operation
6. monitor

**Risk management steps**
1. Frame risk; state it in human language, in a way that effectively communicates this to decision makers 
2. Analyze risk
3. Treat Risk

**Change log**: contains information about approved changes and the change management process. 

**Reduction analysis 5 Key elements**
- Trust boundaries
- Data flow paths
- input points
- privileged operation
- details about security control

**Windows logs**
- Errors: indicate significant problem
- warnings: indicate future problems
- information: describes successful operations
- success audits: record successful security access
- failure audits: records failed security access attempts 

**log rotation**: is an automated process used in system administration in which log files are compressed, moved (archived), renamed or deleted once they are too old or too big

**SIEM**: security information and event management
tool is designed to provide automated analysis and monitoring of logs and security events.

**Authenticated Scans**: 
use a read only account to access configuration files, allowing more accureate testing of vulnerabilities. 

**SOC 1**: an audit report that's scope includes both business process and information technology control objectives and testing

**SOC 2**: attestation report assesses a broader range of controls related to the Trust Services Criteria: security, availability, processing integrity, confidentiality, and privacy

**FISMA** audit: The Federal Information Security Management Act protects government information and assets from unauthorized access, use, disclosure, or destruction.

**SIEM** > **SND** > **SDS** > **SOAR** 
![[Screenshot 2024-09-09 at 14.06.12 1.png]]

BCP
BIA 
DRP

**Information asset risk management program sequence:** 
1. identify compliance requirements
2. establish classification
3. establish categories
4. establish security baseline

**Orchestration**:
involves bringing together data sources from security devices, appliances, or agents in an architecture. 

**Automation**: 
provides scripted control via workflows and playbooks over security activities such as incident response or monitoring and analysis tasks.

**HSM**: Hardware Security Module
provides secure and safe storage and management of sensitive assets such as certificates or the keys used to encrypt archival and backup data.

#### Two forms of Analytics 
- **Predictive Analytics**: Predictive Analytics predicts what is most likely to happen in the future 
- **Descriptive Analytics:** tells you what happened in the past

**Security categorization**: groups together information types that have comparable loss or impacts if compromised, along with any compliance-required security protection requirements for that type of data.

**Risk assessment**: the process of identifying and evaluating risk based on level of importance. 
is included in risk management

**Reverse proxy**: deployed as a screening proxy for web servers

**forensic disc controller** performes 4 functions: 
1. write blocking; intercepts write commands sent to the device and prevents them from modifying data on the device.
2. returning data requested by a read operation
3. returning access-significant information from the device
4. reporting errors from the device back to the forensic host
![[Pasted image 20240911093416.png]]

**Backup Tape Rotation**
- Grandfather/Father/Son
- Tower of Hanoi
- Six Cartridge Weekly

**Logical Acquisition**: focus on specific files  
**Sparse acquisition**: logical acquisition + also collects data from unallocated space
**Bit-by-bit acquisition**: typically performed for a full drive 

**Incident**: a violation or imminent threat (NIST)
**adverse event**: any event with negative consequences (NIST)
**event**: any observable occurrence on a system or network (NIST)

**Hot site**: includes hardware, software and up to date data
**Warm site**: includes some hardware and some data
**cold site**: includes a building with water and electricity. 
**mobile site**: includes equipment ready to move

**electronic vaulting**: automatic and scheduled transmission of backup data to offsite location 

**Crisis management cycle**: 
prepare -> respond -> recover -> mitigate -> prepare

**PCI-DSS**: Payment Card Industri Data Security Standard

**X.509 standard**: contains spec for digital signatures

A cryptographic key is called **ephemeral** if it is generated for each execution of a key establishment process
#### Asymmetric 
**EEC**: Eliptic curve crypt. Asymmetric 
**RSA**: Rivest–Shamir–Adleman
#### Symmetric 
**DES**: 56 bit key
**2DES**: broken using meet-in-the-middle
**3DES**: 112 bit key (replaced by AES)
**AES**: 128, 192, 256 bit key uses **CCMP** (**CCM** with **CRT** mode) 
**Skipjack**: 80 bit key
**Blowfish**: 32-448 bit key
**IDEA**: 128 bit key - International Data Encryption Algorithm 
#### Hash Functions
**MD5** 128 bit
**RC4**: multiple vulnerabilities
**SHA - Secure Hash Algorithms**
![[Screenshot 2024-09-10 at 10.57.59.png]]


**Deluge sprinklers**: unpressurized dry piping & open sprinkler head
**Wet pipe sprinklers**: Water always in piping
**Dry pipe sprinklers**: piping filled with pressurized air or nitrogen. water enters the pipe only when sprinkler head pop and the gas escapes.
**Preaction sprinklers**: dry piping until initial stages of a fire is detected. Water fills piping & is activated when the heads pop.  

**Soda acid and dry powder extinguishers**: removes fuel supply
**Water extinguisher**: suppresses temperature 
**Halon and CO2 extinguisher**: removes oxygen
![[Screenshot 2024-09-11 at 09.52.50.png]]

**Wave pattern motion detector**: uses microwave
**Infrared motion detector**: läser av IR
**Capacitance motion detectors**: senses changes in electromagnetic fields


**1000 BaseT**: (Gigabit ethernet) 100m range limitation
**CAT3**: 10Mbps 
**CAT4**: 50Mbps up, 150 Mbps down 100m
**CAT5**: 100 Mbps 100m
**CAT5e**: 1000 Mbps 100m
**CAT6**: 1000 Mbps 100m
**CAT7**: 10 Gbps 100m
**CAT7a**: 40 Gigabit speeds over 50 meters and 100 Gbps up to 15 meters.

**Portmon**: aging windows tool used to monitor serial ports

**service level agreement (SLA)**:
An agreement between an organization and a vendor. It typically stipulates performance expectations, such as minimum uptime, and can include expectations for the availability and security of data. 

**Operation Level Agreement (OLA)**: 
may cover the same type of things as SLA but its not a formal document

**Wardriving**: used to locate wireless networks with a vehicle
**Warwalking**: used to locate wireless networks with a vehicle
**Wireless site survey**: more detailed
![[Pasted image 20240910124137.png]]




**WAF**: Wes Application Firewall
**PAT**: Port Address Translation
**NAT**: Network Address Translation. -> Same address cant be inside l out
**LDP**: port 515 Laber Distribution Protocol 
**RFC 4217** : FTP over TLS Port: 998-992

**VPN**:
**PPTP**: Point-to-Point Tunneling Protocol
**L2F**: Layer 2 Forwarding
**L2TP**: Layer 2 Tunneling Protocol
**TLS**: Transport layer Security

**Egress Filterings**: Filtrera urgerende dater

**Teardrop attack**: Fragmented TCP packets → targets stack on system that handles frag packets overflows and leads to DOS

**Christmas tree** or **Xmas tree Attack**: Sets an TCP flags, lighting up live a tree

**TCP RST Flag**: indicates to Reset or Disconnect session

**DLP**: Data Loss prevention, prevents data from leaving or being exfiltrated by  monitoring, detecting and blocking sensitive data while _in use_ (endpoint actions), _in motion_ (network traffic), and _at rest_ (data storage).

**VXLAN**:  Virtual Extensible LAN - Virtual layer 2 networks to be created overlaid unstop of layer  3 networks.


**SPAM FILTERS**

- **SPF**: Sender Policy Fame work 
  Runs a check on Email and verifies mail server it was sent from to public SPF Record 

- **DKIM**: Domain Keys Identified Mali 
  uses digital Signatures to Identify authenticity, integrity & nonrepudiation

- **DMARC**: Domain-based Message authentication, Reporting & Conformance
  exertion of **SPF** & **DKIM**

**MBSA**: Microsoft Baseline Security Analyzer
identifies installed & missing patches & Common Security miss-configurations 

**Darknet analysis**: used ot identify malicious traffic

**SCCM** AKA **ConfigMgr** : Microsoft system Center Configuration
distribution of software 

#### IPv4 Classes 
![[Screenshot 2024-09-10 at 13.04.59.png]]
![[Screenshot 2024-09-10 at 13.05.13.png]]

#### Subnetting

![[Screenshot 2024-09-10 at 13.15.56.png]]

#### Private IPv4 addresses
![[Screenshot 2024-09-11 at 12.52.47.png]]
#### Change Management Process
1. **Change submitted**: need for Change identified & submitted.
2. **Change Reviewed**: Can be required a review of _CRB_ (change review board) & _CAB_ change authorization board. _Impact Analysis is made here!_ 
3. **Change approved/rejected** 
4. **Change Implementation**

**Precursor**: observable signals for an event which may suggest that incident may occur in the future

**indicator**:  is a sign that an incident may have occurred or may be occurring now

**ACL**: Access control list
- Focuses on the object (e.g., file, resource, etc.).
- Specifies which subjects (users, groups, or processes) are allowed to access the object and what kind of access they have (read, write, execute, etc.).
- It is essentially a list attached to each object that outlines the permissions for various subjects.

**Access Control Matrix**
- A comprehensive structure that maps all subjects (users, groups, processes) to all objects (files, resources, etc.) in the system.
- Represents the permissions of every subject for every object in a matrix format.
- This is often conceptual because maintaining such a matrix for large systems is impractical due to its size.

**Capability list** (C-list): 
- Focuses on the subject (e.g., a user or a process).
- Specifies what objects a given subject can access and what types of access (read, write, execute, etc.) the subject has for each object.
- Essentially, it is a list of capabilities or access rights that a particular subject has over various objects.

#### NIST classifications:
**Adverse event**: event that could have negative consequences 
**Security incident**: its a violation or imminent threat of violation of security policies and practices. 

**Key escrow**: recovery of private keys 

**Heartbeat sensor**: sends periodic status messages from the alarm system to the monitoring center.

**Security Classification**: is a process that determines possible loss or impact if information of a given type suffers any kind of security compromise.

**Security Categorization**: Groups together information types that have comparable loss or impacts if compromised, along with any compliance-required security protection requirements for that type of data 

**Risk Management process**
1. Perspective: Outcomes, assets, process or threat based`
2. Impact assessment: quantitative or qualitative`
3. Damage limitation: deter, detect, prevent, avoid`
4. Treatment: accept, treat (fix or mitigate), transfer, avoid, recast
**This can be:** 
1. Identify compliance requirements
2. Establish classifications
3. Establish categories
4. Establish security baselines

**Information risk management process**:
1. Set priorities
2. Assess risks
3. Select controls and countermeasures
4. Implement controls
5. Validate correct operation
6. Monitor

**IPS and IDS uses**: Signature and Protocol algorithms in their analysis engines 

Project scope and planning phase of Business Continuity Planning: includes 4 actions
- a structured analysis of the organization
- the creation of a BCP team
- assessment of available resources
- analysis of the legal and regulatory landscape

**Routing protocols** - all associated with routers
- **ARP**: Address Resolution Protocol
- **BGP**: Border Gateway Protocol 
- **OSPF**: Open Shortest Path

**Full Backup**: Backs up all data in a single backup job. Changes archive bit.  
**Incremental**: Backs up all data since the last backup (i.e. new and modified). 
Changes archive bit
**Differential**: Backs up all data changed since the last full backup. Does not change archive bit.
**Copy Backup**: Makes a full backup but does not change the archive bit

**Disaster recovery test types**, from least impactful to most impactful
1. **checklist review**
2. **parallel test**
3. **tabletop exercise**
4. **full interruption test**
#### System High Mode
- _Proper clearance required for **ALL** information on the system_. 
- _All users can access **SOME** data, based on their need to know_.
All users that have access must have a security clearance that authorizes their access. Although all users have access, they may not have a “need to know” for all the information because there are various levels of information classification. The levels of information classification are clearly labeled to make it clear what the access requirements are. 
#### Compartment Mode
- _Proper clearance required for THE HIGHEST LEVEL of information on the system. _
- _All users can access SOME data, based on their need to know and formal access approval._
All users that have access to the system must have a security clearance that authorizes their access. Each user is authorized to access the information only when a “need to know” requirement can be justified. A strict documentation process tracks the access given to each user and the individual who granted the access. 

#### Multilevel Secure Mode (MLS)
- _Proper clearance required for ALL information on the system. _
- _All users can access SOME data, based on their need to know, formal access approval and clearance level._
All users that have access to the system must have a security clearance that authorizes their access. Uses data classification and Mandatory Access Control (MAC) to secure the system. Processes and data are controlled. Processes from lower security levels are not allowed to access processes at higher levels. 

 **Microsoft STRIDE** threat assessment model: places threats into one of 6 categories.
 (Useful for threat categorization)
1. Spoofing
2. Tampering
3. Repudiation
4. Information Disclosure
5. DOS
6. Elevation of privileges

**Vulnerability management** informs the planning and conduct of **continioius assessment**, the results of which are used as updates to **vulnerability management**.
#### Reduction Analysis
**Reduction analysis 5 Key elements**
- Trust boundaries
- Data flow paths
- input points
- privileged operation
- details about security control  

**NIST Publications**: are mandatory for government agencies or companies on government contractors

**RFC 1918** : internal IP addresses

**Netflow records**: Contain an entry for every network communication session that took place on a network and can be compared to a list of known malicious hosts.

**Regression Testing**:
![[Screenshot 2024-09-09 at 14.19.22.png]]

**Orchestration**: involves bringing together data sources from security devices, appliances, or agents in an architecture.

**Automation**: provides scripted control via workflows and playbooks over security activities such as incident response or monitoring and analysis tasks.

![[Screenshot 2024-09-09 at 14.55.38.png]]

![[Screenshot 2024-09-09 at 15.28.22.png]]

**Ferderation**: Links identity between organizations`

**Information Systems**: is a set of information processes & technologies & Interfaces that work together to suit the needs of the Systemowners & Users`

**Just-in-time Securily**: Fundamental Security practice where the privilidges are granted in a limited or a predetermined time. delivering tools, tequniques & info in the right moment the user needs it`
#### GDPR roles:
* **Subject**: The person described or Identified by the data`
* **Processor**: A person or Organization that creates, modifies, uses, destroys, or Shares the protected data
* **Controler**: The person or organization who has ultimate data protection responsibility for it`
* **Custodian**: A person or organization who stores the data & makes it available when directed by the controller`
* **Data protection Officer**: A specified officer or individual of an organization who acts as the focal point for all data protection Compliance issues.`

**Recilience**: the ability ot bend, adapt, tolerate, or even ignore unanticipated disruptions, without completely breaking down.`

**Continuity**: is about planning alternative modes of action- having a stack of "just-in-case" options already laid out in plans, proacedures , Software or other IT Elements`

**Shadow IT**: The Key ot determiner of whether user-decined a User-maintained "stuff" is shadow it. The amount of buisness logic that embeds/implements the more business logic the greater the risk.

**Supernet**: Made up of two or more networks`

**Bastion Host**: Server used to access an internal network from an external network. Enable secure access for authorized users`
#### Firewall
![[Screenshot 2024-09-12 at 10.50.39.png]]

**Packet filtering Firewall**: Normal, uses rules line iP address.

**Static Packet Filtering Firewall**: Destination + Source Port

**Stateful Inspection Firewall**: Monitors entire state of the connection & applies normal filters for contents.Delivers extensive logging but resource intensive.

**Circuit-level gateway firewall**: Based on, ip, port (sorce & destination). It verifies the transmission control protocol (TCP) or user datagram protocol (UDP) packets on a virtual circuit between the two transport layers.

**Application-level Gateway Firewall**: Uses proxies for each Service it filters. Each proxie is designed ot Analyze traffic for its specific traffic type, alowing it to better understand valid traffic & prevent Attacks

#### OSI and TCP/IP
![[Screenshot 2024-09-12 at 10.45.29.png]]

#### Ports

![[Screenshot 2024-09-12 at 11.27.44.png]]
![[Screenshot 2024-09-12 at 11.28.09.png]]
![[Screenshot 2024-09-12 at 11.29.07.png]]
![[Screenshot 2024-09-12 at 11.40.47.png]]
![[Screenshot 2024-09-12 at 11.25.16.png]]
![[Screenshot 2024-09-12 at 11.41.09.png]]
![[Screenshot 2024-09-12 at 11.41.37.png]]
![[Screenshot 2024-09-12 at 11.41.59.png]]
![[Screenshot 2024-09-12 at 11.43.08.png]]
![[Screenshot 2024-09-12 at 11.43.50.png]]
![[Screenshot 2024-09-12 at 11.44.09.png]]
![[Screenshot 2024-09-12 at 11.46.18.png]]
![[Screenshot 2024-09-12 at 11.46.48.png]]
![[Screenshot 2024-09-12 at 11.48.31.png]]
![[Screenshot 2024-09-12 at 11.47.49.png]]
![[Screenshot 2024-09-12 at 11.52.04.png]]
![[Screenshot 2024-09-12 at 11.52.38.png]]
![[Screenshot 2024-09-12 at 11.53.11.png]]
#### Network devices
![[Screenshot 2024-09-12 at 10.50.18.png]]


**RADIUS** (Remote Authentication Dial-In User service): Simplest method of providing user authentication. RADIUS server holds a list of usernames and passwords that systems on the network refer to when authenticating a user. RADIUS supports a number of popular protocols such as PPP, PAP and CHAP. RADIUS uses UDP along with client and server model. RADIUS encrypts only the password the remainder of the packet is unencrypted. A third party could capture other information, such as username, authorized services. RADIUS combines authentication and authorization.

**TACACS** (Terminal Access Controller Access Control System): Provides remote authentication and event logging using UDP as communication protocol. User tries to log into a TACACS device, the device refers to the TACACS server to authenticate the user. This provides a central location for all usernames and passwords to be stored. Does not allow for a device to prompt a user to allow them to change their password. It also does not use dynamic password tokens. The information is NOT encrypted.

**TACACS+** (Terminal Server Controller Access Control Systems Plus): Provides enhancements to the standard version of TACACS. It allows users the ability to change their password; dynamic password tokens so that the tokens can be resynchronized; also provides better auditing capabilities. TACACS+ uses TCP as its communication protocol. Encrypts the entire body of the packet but leaves a standard TACACS+ header.  

**PPP** - Point-to-Point: Is used to encapsulate messages and transmit them through an IP network.  

**PAP** - Password Authentication Protocol: Provides identification and authentication of the user attempting to access a network from the remote system. (User should enter a password). The user's name and password are sent over the wire to a server, for comparison with the database. Sniffing is possible because the password can be captured.  

**CHAP** - Challenge Handshake Authentication Protocol: An authentication protocol that uses challenge/response mechanism to authenticate instead of sending a username and password. Avoids sending passwords in any form over the wire by using a challenge/response technique. CHAP is better than PAP. The authentication can be repeated any number of times to ensure the “Replay” attacks is not possible.  

**Serial Line Internet Protocol (SLIP), and Point-to-Point Protocol (PPP):** Works at layer 2 (Datalink) to connect two systems over a serial line, (point-to-point communication line using a dial-up modem), some way is needed to transport IP packets (a network layer activity) across the serial link (a data link layer activity). The following two schemes generally used, SLIP and PPP. PPP has replaced SLIP, because the later does not do error detection, dynamic assignment of IP addresses and data compression.  

**Point to point tunneling protocol (PPTP)**: PPTP was developed by Microsoft to provide virtual dial-up services. PPTP is an encapsulation protocol based on PPP and encrypts and encapsulates PPP packets.  

**Layer 2 Tunneling Protocol (L2TP)**: The extension of point-to-point protocol (PPP). L2TP is also called a "virtual dial-up protocol" because it extends a dial-up PPP session across the Internet. The client's PPP frames are encapsulated into IP packets with an L2TP tunneling header and sent across the Internet connection.  
L2TP was derived from PPTP features and Cisco protocol called L2F (Layer 2 Forwarding).
- supports _TACACS+_ and _RADIUS_ authentication. PPTP does NOT.
- also supports more protocols than PPTP, including IPX, SNA, and others.
- Microsoft continues to support PPTP for its Windows products, but L2TP is preferred over PPTP.
- **IPSec** is now the Internet standard for tunneling and secure VPNs.

**Layer 2 Forward Protocol (L2F)**: Used to establish a secure tunnel across Internet developed by Cisco. This tunnel creates a virtual point-to-point connection between the user and the enterprise customer's network. L2F allows encapsulation of PPP/SLIP packets within L2F. Not used by IPSec. It is used by VPNs.

    
    6.12.2 Application Layer Security Protocols
    
    Secure Sockets Layer (SSL): SSL developed by Netscape for establishing authenticated and encrypted sessions between Web servers and Web clients. See p.23 for more.  
    Transport layer security (TLS): The IETF's version of SSL v3.0. Uses Diffie-Hellman public-key cryptography. TLS also uses HMAC (Hashed Message Authentication Code), a core protocol essential for security on the Internet along with IPSec. HMAC is the mechanism for message authentication that uses either MD5 or SHA-1 hash functions in combination with a shared secret key.